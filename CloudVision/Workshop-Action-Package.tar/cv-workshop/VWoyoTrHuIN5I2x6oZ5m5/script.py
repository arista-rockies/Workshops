# Copyright (c) 2022 Arista Networks, Inc.
# Use of this source code is governed by the Apache License 2.0
# that can be found in the COPYING file.


# List of commands to be run on the switch
cmds = [
    'enable',
    'configure',
    'daemon TerminAttr',
    'shutdown',
    'no shutdown'
    ]

# Create log entry
ctx.alog('Restarting TerminAttr')

# Run the list of commands on the switch
cmdResponse = ctx.runDeviceCmds(cmds)

# Throw and error if an error was received
for cmd in cmdResponse:
    cmdErr = cmdResponse[0].get('error')
    if cmdErr:
        raise ActionFailed(f'Command failed with: {cmdErr}')

# Create log entry
ctx.alog('TerminAttr Sucessfully Restarted')