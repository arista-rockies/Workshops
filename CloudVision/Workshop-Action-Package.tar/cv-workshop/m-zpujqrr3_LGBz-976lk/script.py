# Copyright (c) 2022 Arista Networks, Inc.
# Use of this source code is governed by the Apache License 2.0
# that can be found in the COPYING file.


import time

# Interface needing to by cycled provided by user in the "Ethernet" argument 
interface = ctx.action.args.get("Ethernet")

# Seconds to wait between the disable / enable provided by the user in the "wait" argument.
sleepTime = int(ctx.action.args.get("SleepTime"))

# List of commands to be run on the switch to disable the interface
disableCmds = [
    'enable',
    'configure',
    f'interface Ethernet{interface}',
    'shutdown'
    ]

# Create log entry
ctx.alog(f'Disabling Ethernet{interface}')

# Run the list of commands on the switch
cmdResponse = ctx.runDeviceCmds(disableCmds)

# Throw and error if an error was received
for cmd in cmdResponse:
    cmdErr = cmdResponse[0].get('error')
    if cmdErr:
        raise ActionFailed(f'Command failed with: {cmdErr}')

# Create log entry
ctx.alog(f'Interface Ethernet{interface} Sucessfully Disabled')

# Create log entry
ctx.alog(f'Sleeping for {sleepTime} seconds before re-enabling Ethernet{interface}')

# Wait 5 seconds before re-enabling the interface
time.sleep(sleepTime)

# List of commands to be run on the switch to enable the interface
enableCmds = [
    'enable',
    'configure',
    f'interface Ethernet{interface}',
    'no shutdown'
    ]

# Create log entry
ctx.alog(f'Enabling Ethernet{interface}')

# Run the list of commands on the switch
cmdResponse = ctx.runDeviceCmds(enableCmds)

# Throw and error if an error was received
for cmd in cmdResponse:
    cmdErr = cmdResponse[0].get('error')
    if cmdErr:
        raise ActionFailed(f'Command failed with: {cmdErr}')

# Create log entry
ctx.alog(f'Interface Ethernet{interface} Sucessfully Enabled')